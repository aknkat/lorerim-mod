Scriptname LKS_KeenSensesEffect extends ActiveMagicEffect
; Short activation trigger only. Cooldown state belongs to the quest controller.
; Retain the three legacy properties so old saved instances can finish safely.

Spell Property DetectionSpell Auto
Race Property KhajiitRace Auto
Race Property KhajiitVampireRace Auto
Quest Property CooldownController Auto

Event OnEffectStart(Actor akTarget, Actor akCaster)
    Debug.Notification("LKS: INPUT")
    Actor playerRef = Game.GetPlayer()
    If akTarget != playerRef || akCaster != playerRef
        Debug.Notification("LKS: ERROR - not PlayerRef")
    ElseIf CooldownController == None
        Debug.Notification("LKS: ERROR - controller not bound")
    Else
        Bool controllerReady = CooldownController.IsRunning()
        If !controllerReady
            controllerReady = CooldownController.Start()
        EndIf
        If controllerReady
            LKS_KeenSensesController controller = CooldownController as LKS_KeenSensesController
            If controller != None
                controller.LKSProbe()
            Else
                Debug.Notification("LKS: ERROR - script cast None")
            EndIf
        Else
            Debug.Notification("LKS: ERROR - Start failed")
        EndIf
    EndIf
EndEvent
