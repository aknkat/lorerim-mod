Scriptname LKS_KeenSensesEffect extends ActiveMagicEffect
; Short activation trigger only. Cooldown state belongs to the quest controller.
; Retain the three legacy properties so old saved instances can finish safely.

Spell Property DetectionSpell Auto
Race Property KhajiitRace Auto
Race Property KhajiitVampireRace Auto
Quest Property CooldownController Auto

Event OnEffectStart(Actor akTarget, Actor akCaster)
    Debug.MessageBox("LKS DIAG3: INPUT START\nClose this message to continue to the controller report.")
    Actor playerRef = Game.GetPlayer()
    If akTarget != playerRef || akCaster != playerRef
        Debug.MessageBox("LKS DIAG3: target or caster is not PlayerRef.")
    ElseIf CooldownController == None
        Debug.MessageBox("LKS DIAG3: CooldownController is not bound.")
    Else
        Bool controllerReady = CooldownController.IsRunning()
        If !controllerReady
            controllerReady = CooldownController.Start()
        EndIf
        If controllerReady
            LKS_KeenSensesController controller = CooldownController as LKS_KeenSensesController
            If controller != None
                controller.LKSProbe()
            Else
                Debug.MessageBox("LKS DIAG3: controller script cast returned None.")
            EndIf
        Else
            Debug.MessageBox("LKS DIAG3: controller quest Start failed.")
        EndIf
    EndIf
EndEvent
