﻿LoreRim Spoiler Safe Loading - Echoes + TESL 0.2.0 WQHD

今回の修正理由
診断結果の選択プロファイルDefaultでは、0.1.1のDDSとTESLのNIFは正しく優先されていました。
しかし旧Echoes差し替えが有効一覧になく、EchoesのNIF450個は元MODから供給されていました。
0.1.1は旧Echoes差し替えへの依存が残る構成でした。本版はEchoes450個を追加し、その依存をなくします。

MO2での更新（この追加パッチだけを更新）
1. 現在の追加パッチ「[No Delete] Spoiler Safe TESL Skyrim Coverage Patch」を本ZIPでReplaceしてください。
   または旧追加パッチを無効化し、本ZIPを新規の別MODとして導入してください。両方を行う必要はありません。
2. 現在と同じく左ペイン最高優先度にして有効化してください。元Echoes/TESL/Fully IsolatedへMerge/Replaceしないでください。
3. 診断時にMO2が記録した選択プロファイルはDefaultでした。そこで検証する場合、プロファイルを切り替える必要はありません。
   別プロファイルでは有効状態が独立しているため、本版の有効化を確認してください。
ESPの順序・SSE Display Tweaks・メインメニュー設定は変更不要。旧Echoes差し替えを追加で有効化する必要もありません。

内容と変更範囲
- meshes/EchoesofTamriel/ 以下450個。元のユーザー提供Echoes差し替えNIFとバイト単位で同一。
- meshes/TESL-LoadingScreens/ 以下110個。0.1.1とバイト単位で同一。
- textures/EchoesofTamriel/SkyrimWallpaper.dds 1個。0.1.1と同じ指定画像、2560×1440 DXT5。
0.1.1から画像とTESLのNIFは変更せず、EchoesのNIF450個を追加しています。
ESP・DLL・スクリプト・INI・main menu/interfaceファイルは含みません。
元MODのディスク上のファイルを編集せず、仮想Data上のロード画面用NIFと画像だけを上書きします。
DDSのみの差し替えではありません。既存の差し替えNIFで形状・材質も置換する方式です。

検査済み
診断で検出した全560 NIFパスとの一致、受領したEchoes/TESLの全410 LSCR→STAT→NIF参照の網羅、
全NIFの同梱DDS参照、画像の寸法・再読み込み、ZIP CRC、SHA256、元NIFとの一致を確認しました。
同梱のSHA256SUMS.txtにハッシュ一覧を記録しています。

実機確認（新版導入後の1回にまとめる）
完全終了状態からMO2の対象プロファイルで起動し、メインメニューの表示が維持されること、
初回ロード・屋内外移動・ファストトラベルで指定の猫人画像と16:9表示が維持されることを確認してください。
本番セーブの上書きは不要です。旧画像が出た場合は、どのロード場面かとその画像だけを記録してください。
ゲーム実機未検証。診断はMO2の保存済み設定からの推定で、実行中のVFSや描画を直接観測したものではありません。
受領したEchoes/TESL以外の全MODにある未調査LSCRまで網羅したという意味ではありません。
